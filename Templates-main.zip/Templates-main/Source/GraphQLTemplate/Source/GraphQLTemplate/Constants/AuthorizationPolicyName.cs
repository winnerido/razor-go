namespace GraphQLTemplate.Constants;

public static class AuthorizationPolicyName
{
    public const string Admin = nameof(Admin);
}
