namespace GraphQLTemplate.Constants;

public static class CorsPolicyName
{
    public const string AllowAny = nameof(AllowAny);
}
