namespace GraphQLTemplate.Constants;

public static class CacheProfileName
{
    public const string StaticFiles = nameof(StaticFiles);
}
