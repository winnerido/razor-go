namespace NuGetTemplate;

#if Comments
/// <summary>
/// Some class.
/// </summary>
#endif
public class Class1
{
}
