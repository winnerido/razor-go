#if (!ImplicitUsings || DotnetFramework)
using System;

#endif
[assembly: CLSCompliant(true)]
