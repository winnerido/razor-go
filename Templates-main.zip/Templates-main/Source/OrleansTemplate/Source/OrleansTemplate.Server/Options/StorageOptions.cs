namespace OrleansTemplate.Server.Options;

public class StorageOptions
{
    public string ConnectionString { get; set; } = default!;
}
