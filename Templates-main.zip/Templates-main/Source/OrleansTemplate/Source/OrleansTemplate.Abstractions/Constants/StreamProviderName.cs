namespace OrleansTemplate.Abstractions.Constants;

public static class StreamProviderName
{
    public const string Default = nameof(Default);
}
