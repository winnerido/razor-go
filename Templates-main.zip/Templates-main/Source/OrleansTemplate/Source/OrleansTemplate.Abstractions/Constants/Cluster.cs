namespace OrleansTemplate.Abstractions.Constants;

public static class Cluster
{
    public const string ClusterId = "ClusterId";
    public const string ServiceId = "ServiceId";
}
