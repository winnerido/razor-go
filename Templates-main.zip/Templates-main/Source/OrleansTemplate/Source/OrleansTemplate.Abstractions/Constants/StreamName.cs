namespace OrleansTemplate.Abstractions.Constants;

public static class StreamName
{
    public const string Reminder = nameof(Reminder);
    public const string SaidHello = nameof(SaidHello);
}
