namespace ApiTemplate.Constants;

public static class ApiVersionName
{
    public const string V1 = "1.0";
}
