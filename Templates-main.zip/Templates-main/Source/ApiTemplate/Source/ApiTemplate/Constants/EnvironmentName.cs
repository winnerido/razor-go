namespace ApiTemplate.Constants;

public static class EnvironmentName
{
    public const string Test = nameof(Test);
}
