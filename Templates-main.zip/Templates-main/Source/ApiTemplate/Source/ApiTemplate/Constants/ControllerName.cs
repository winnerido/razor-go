namespace ApiTemplate.Constants;

public static class ControllerName
{
    public const string Cars = nameof(Cars);
}
