# Security Policy

## Supported Versions

This project supports only the latest version with security updates. However, we'll do our best to help and answer questions about older versions.

## Reporting a Vulnerability

Contact [Muhammad Rehan Saeed](https://github.com/RehanSaeed) to report a security vulnerability. You will be thanked!
